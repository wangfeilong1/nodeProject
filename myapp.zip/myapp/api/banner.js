var express = require('express');
var router = express.Router();
var sql = require("../tool/sql");//引入数据库封装的sql方法
// var xlsx = require("node-xlsx");  //这个是引入的解析Excel表格的数据的包‘
var filemd = require("../tool/file_banner");//引入封装好的导入数据方法；

   
router.get('/', function(req, res, next) {
  if (req.session.isLogin != 1) { // 表示未登录
    res.redirect('/login'); // 跳转到登录页面
    return; // 代码将不再继续往下执行
  }
      let { pageCode, pageNumber } = req.query;
      pageCode = pageCode *1 || 1;
      pageNumber = pageNumber * 1 || 8;
      sql.find("sh1811", "banner", {}).then((data) =>{
        const totalNumber = Math.ceil( data.length / pageNumber);
        data = data.splice((pageCode - 1) * pageNumber, pageNumber)
        sql.distinct("sh1811", "banner", "name").then((Arr) =>{//成功之后返回的数据;
          res.send({
            code: 200,
            message: 'success',
            data: dat
    }).catch((err) =>{
      console.log(err)
    })  
  })                                  
})
});
// 侧边栏样式
   
      //添加用户
router.post("/addAction", function(req, res, next ){
    //
    // post 拿数据的方法是 const obj = req.body;
    // get 拿数据的方法是 const obj = req.query；
    let  {id,p1,p2,p3,p4,p5,name} = req.body;
    id=id*1;
   sql.find("sh1811", "banner", {id:id} ).then(data =>{
      if(data.length == 0){
        //数据库中没有商品数据;直接进行添加，，
        sql.insert("sh1811", "banner", {id,p1,p2,p3,p4,p5,name})
        .then(() =>{
          res.send({
            code: 200,
            message: 'success',
            data: 1
          })
  }).catch(err =>{
    res.send({
			code: 200,
			message: 'success',
			data: data
		})
	 })
  }
})
})
//删除商品
router.get("/remove",function(req, res, next ){
    let { id } =req.query;
    id = id*1;
    sql.remove("sh1811", "banner",{ id }).then( ()=>{
      res.send({
        code: 200,
        message: 'success',
        data: data
      })
      
    })
  })
  //删除全部商品
router.get("/deleteall", function(req, res, next){
    sql.remove("sh1811", "banner", {}).then( ()=>{
      res.send({
        code: 200,
        message: 'success',
        data: 1
      })
    }).catch(err => {
      res.send({
        code: 200,
        message: 'success',
        data: 0
      })
    })
});
//修改
router.post("/updateAction", function(req, res, next){
      let  {id,p1,p2,p3,p4,p5,name} = req.body;
      
      id = id*1;
      
      //post的获取数据的方法；
      sql.update("sh1811", "banner", "updateOne", { id},  { $set :{id,p1,p2,p3,p4,p5,name}})
    .then(() =>{//修改成功或者失败都会返回product.ejs页面；
      res.send({
        code: 200,
        message: 'success',
        data: 1
      })
    }).catch(err => {
      res.send({
        code: 200,
        message: 'success',
        data: 0
      })
    })
    });

// 搜索和分页
router.get('/search', (req, res, next) => {
	const { name } = req.query;
	sql.find('sh1811', 'banner', { name: eval('/'+name+'/') }).then(data => {
        sql.distinct("sh1811", "banner", "name").then((Arr) =>{//成功之后返回的数据
          res.send({
            code: 200,
            message: 'success',
            data: data
          })
        })
        })
})
//分类
router.get("/distinct", (req, res, next) =>{
    sql.distinct("sh1811", "banner", "name").then((Arr) =>{//成功之后返回的数据;
        res.send(Arr);
    })
})
router.get("/nameSearch" , (req, res, next) =>{
    let { name } = req.query;
    sql.find("sh1811" , "banner" , { name }).then((data) =>{
       sql.distinct("sh1811", "banner", "name").then((Arr) =>{
        res.send({
          code: 200,
          message: 'success',
          data: data
        })
        
      })
})
})

// // 排序；

router.get("/sort", (req, res, next) =>{
    let { type, num} = req.query;
    let sortData = {};
    sortData[type] = num * 1;
    sql.sort("sh1811", "banner", sortData).then((data) =>{
        sql.distinct("sh1811", "banner", "name").then( (Arr) =>{
          res.send({
            code: 200,
            message: 'success',
            data: data
          })
        })
        })
})
router.get("/distinct", (req, res, next) =>{
  sql.distinct("sh1811", "banner", "name").then((Arr) =>{//成功之后返回的数据;
      res.send(Arr);
  })
})

module.exports = router;
